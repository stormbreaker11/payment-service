package com.eureka.item;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemCatalog1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
